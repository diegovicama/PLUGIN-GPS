import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var contadoresLayer: null
    property var caminoNodosLayer: null
    property var listaContadores: []

    // Contador seleccionado
    property var destinoId: null
    property var destinoNombre: ""
    property var destinoGeometria: null
    property var destinoPunto: null

    // Nodos encontrados
    property var nodoUsuarioFid: null
    property var nodoDestinoFid: null

    function cargarContadores() {

        contadoresLayer =
            qgisProject.mapLayersByName("CONTADORES")[0]

        if (!contadoresLayer) {
            iface.mainWindow().displayToast(
                "No se encontró la capa CONTADORES"
            )
            return
        }

        var lista = []

        var it = LayerUtils.createFeatureIterator(
            contadoresLayer
        )

        while (it.hasNext()) {

            var feature = it.next()

            lista.push({
                nombre: String(
                    feature.attribute("NOMBRE")
                ),
                id: feature.id
            })
        }

        listaContadores = lista
    }

    function actualizarLista() {

        var texto =
            buscador.text.toLowerCase()

        listaModelo.clear()

        for (
            var i = 0;
            i < listaContadores.length;
            i++
        ) {

            var nombre =
                listaContadores[i].nombre

            if (
                texto === "" ||
                nombre.toLowerCase().indexOf(texto) !== -1
            ) {

                listaModelo.append({
                    nombre: nombre,
                    id: listaContadores[i].id
                })
            }
        }
    }

    function seleccionarContador(featureId) {

        if (!contadoresLayer) {
            return
        }

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var feature = it.next()

            if (feature.id === featureId) {

                destinoId = feature.id

                destinoNombre =
                    String(
                        feature.attribute("NOMBRE")
                    )

                destinoGeometria =
                    feature.geometry

                destinoPunto =
                    GeometryUtils.centroid(
                        feature.geometry
                    )

                // Centrar el mapa sobre el contador
                var puntoMapa =
                    GeometryUtils.reprojectPoint(
                        destinoPunto,
                        contadoresLayer.crs,
                        qgisProject.crs
                    )

                iface.mapCanvas().mapSettings.center =
                    puntoMapa

                selectorContador.close()

                // Buscar los dos nodos
                buscarNodosMasCercanos()

                return
            }
        }

        iface.mainWindow().displayToast(
            "No se encontró el contador seleccionado"
        )
    }

    function buscarNodosMasCercanos() {

        caminoNodosLayer =
            qgisProject.mapLayersByName(
                "CAMINO NODOS"
            )[0]

        if (!caminoNodosLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa CAMINO NODOS"
            )

            return
        }

        // ------------------------------------------------
        // 1. OBTENER POSICIÓN GPS
        // ------------------------------------------------

        var positioning =
            iface.findItemByObjectName(
                "positionSource"
            )

        if (!positioning) {

            iface.mainWindow().displayToast(
                "No se encontró el GPS de QField"
            )

            return
        }

        if (!positioning.active) {

            iface.mainWindow().displayToast(
                "El GPS de QField no está activo"
            )

            return
        }

        var info =
            positioning.positionInformation

        if (
            !info.longitudeValid ||
            !info.latitudeValid
        ) {

            iface.mainWindow().displayToast(
                "La posición GPS todavía no es válida"
            )

            return
        }

        // GPS en WGS84
        var gpsPoint =
            GeometryUtils.point(
                info.longitude,
                info.latitude
            )

        // GPS convertido al CRS del proyecto
        var usuarioPunto =
            GeometryUtils.reprojectPoint(
                gpsPoint,
                CoordinateReferenceSystemUtils.wgs84Crs(),
                qgisProject.crs
            )

        // ------------------------------------------------
        // 2. PUNTO DEL CONTADOR EN CRS DEL PROYECTO
        // ------------------------------------------------

        var contadorPunto =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs
            )

        // ------------------------------------------------
        // 3. BUSCAR LOS NODOS MÁS CERCANOS
        // ------------------------------------------------

        var it =
            LayerUtils.createFeatureIterator(
                caminoNodosLayer
            )

        var distanciaUsuarioMinima =
            Number.POSITIVE_INFINITY

        var distanciaDestinoMinima =
            Number.POSITIVE_INFINITY

        var fidUsuario = null
        var fidDestino = null

        while (it.hasNext()) {

            var nodo = it.next()

            // Los nodos son puntos.
            var nodoPunto =
                GeometryUtils.centroid(
                    nodo.geometry
                )

            // Pasamos el nodo al CRS del proyecto.
            var nodoPuntoMapa =
                GeometryUtils.reprojectPoint(
                    nodoPunto,
                    caminoNodosLayer.crs,
                    qgisProject.crs
                )

            // Distancia nodo → usuario
            var distanciaUsuario =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    usuarioPunto
                )

            if (
                distanciaUsuario <
                distanciaUsuarioMinima
            ) {

                distanciaUsuarioMinima =
                    distanciaUsuario

                fidUsuario =
                    nodo.attribute("fid")
            }

            // Distancia nodo → contador
            var distanciaDestino =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    contadorPunto
                )

            if (
                distanciaDestino <
                distanciaDestinoMinima
            ) {

                distanciaDestinoMinima =
                    distanciaDestino

                fidDestino =
                    nodo.attribute("fid")
            }
        }

        // Guardamos los FID encontrados
        nodoUsuarioFid = fidUsuario
        nodoDestinoFid = fidDestino

        // ------------------------------------------------
        // 4. MOSTRAR RESULTADO
        // ------------------------------------------------

        if (
            fidUsuario === null ||
            fidDestino === null
        ) {

            iface.mainWindow().displayToast(
                "No se pudieron encontrar los nodos"
            )

            return
        }

        iface.mainWindow().displayToast(
            "Usuario → nodo FID: " +
            fidUsuario +
            " | Destino → nodo FID: " +
            fidDestino
        )
    }

    QfToolButton {
        id: botonRuta

        iconSource:
            Theme.getThemeVectorIcon(
                "ic_navigation_white_24dp"
            )

        iconColor:
            Theme.toolButtonColor

        bgcolor:
            Theme.toolButtonBackgroundColor

        round: true

        onClicked: {

            cargarContadores()

            actualizarLista()

            selectorContador.open()
        }
    }

    QfDialog {
        id: selectorContador

        parent:
            iface.mainWindow().contentItem

        width:
            Math.min(
                500,
                iface.mainWindow().width - 40
            )

        height:
            Math.min(
                700,
                iface.mainWindow().height - 40
            )

        x:
            (iface.mainWindow().width - width) / 2

        y:
            (iface.mainWindow().height - height) / 2

        title: "Seleccionar contador"

        Column {
            anchors.fill: parent
            anchors.margins: 16

            spacing: 10

            TextField {
                id: buscador

                width: parent.width

                placeholderText:
                    "Buscar contador..."

                onTextChanged: {
                    actualizarLista()
                }
            }

            ListView {
                id: lista

                width: parent.width

                height:
                    parent.height -
                    buscador.height -
                    10

                clip: true

                model: listaModelo

                delegate: ItemDelegate {

                    width: lista.width

                    text: model.nombre

                    onClicked: {

                        seleccionarContador(
                            model.id
                        )
                    }
                }
            }
        }
    }

    ListModel {
        id: listaModelo
    }

    Component.onCompleted: {

        iface.addItemToPluginsToolbar(
            botonRuta
        )

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}