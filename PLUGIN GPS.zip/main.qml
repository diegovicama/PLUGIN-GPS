import QtQuick
import QtQuick.Controls
import org.qfield

Item {
    id: plugin

    Button {
        id: botonRuta

        text: "RUTA"

        anchors.centerIn: parent

        onClicked: {
            iface.mainWindow().displayToast(
                "Abrir selección de contador"
            )
        }
    }

    Component.onCompleted: {
        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}