import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    QfToolButton {
        id: botonRuta

        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: {
            selectorContador.open()
        }
    }

    QfDialog {
        id: selectorContador

        parent: iface.mainWindow().contentItem

        width: Math.min(500, iface.mainWindow().width - 40)
        height: Math.min(700, iface.mainWindow().height - 40)

        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        title: "Seleccionar contador"

        Column {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            TextField {
                id: buscador

                width: parent.width

                placeholderText: "Buscar contador..."
            }

            Label {
                text: "Aquí aparecerá la lista de contadores"
                width: parent.width
            }
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(botonRuta)

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}