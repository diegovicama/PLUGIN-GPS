import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var contadoresLayer: null
    property var caminoNodosLayer: null
    property var caminoLineasLayer: null
    property var rutaActivaLayer: null

    property var listaContadores: []

    // Contador seleccionado
    property var destinoId: null
    property var destinoNombre: ""
    property var destinoGeometria: null
    property var destinoPunto: null

    // Nodos encontrados
    property var nodoUsuarioFid: null
    property var nodoDestinoFid: null

    function cargarContadores() {

        contadoresLayer =
            qgisProject.mapLayersByName("CONTADORES")[0]

        if (!contadoresLayer) {
            iface.mainWindow().displayToast(
                "No se encontró la capa CONTADORES"
            )
            return
        }

        var lista = []

        var it = LayerUtils.createFeatureIterator(
            contadoresLayer
        )

        while (it.hasNext()) {

            var feature = it.next()

            lista.push({
                nombre: String(
                    feature.attribute("NOMBRE")
                ),
                id: feature.id
            })
        }

        listaContadores = lista
    }

    function actualizarLista() {

        var texto =
            buscador.text.toLowerCase()

        listaModelo.clear()

        for (
            var i = 0;
            i < listaContadores.length;
            i++
        ) {

            var nombre =
                listaContadores[i].nombre

            if (
                texto === "" ||
                nombre.toLowerCase().indexOf(texto) !== -1
            ) {

                listaModelo.append({
                    nombre: nombre,
                    id: listaContadores[i].id
                })
            }
        }
    }

    function seleccionarContador(featureId) {

        if (!contadoresLayer) {
            return
        }

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var feature = it.next()

            if (feature.id === featureId) {

                destinoId = feature.id

                destinoNombre =
                    String(
                        feature.attribute("NOMBRE")
                    )

                destinoGeometria =
                    feature.geometry

                destinoPunto =
                    GeometryUtils.centroid(
                        feature.geometry
                    )

                var puntoMapa =
                    GeometryUtils.reprojectPoint(
                        destinoPunto,
                        contadoresLayer.crs,
                        qgisProject.crs
                    )

                iface.mapCanvas().mapSettings.center =
                    puntoMapa

                selectorContador.close()

                buscarNodosMasCercanos()

                return
            }
        }

        iface.mainWindow().displayToast(
            "No se encontró el contador seleccionado"
        )
    }

    function buscarNodosMasCercanos() {

        caminoNodosLayer =
            qgisProject.mapLayersByName(
                "CAMINO NODOS"
            )[0]

        if (!caminoNodosLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa CAMINO NODOS"
            )

            return
        }

        var positioning =
            iface.findItemByObjectName(
                "positionSource"
            )

        if (!positioning) {

            iface.mainWindow().displayToast(
                "No se encontró el GPS de QField"
            )

            return
        }

        if (!positioning.active) {

            iface.mainWindow().displayToast(
                "El GPS de QField no está activo"
            )

            return
        }

        var info =
            positioning.positionInformation

        if (
            !info.longitudeValid ||
            !info.latitudeValid
        ) {

            iface.mainWindow().displayToast(
                "La posición GPS todavía no es válida"
            )

            return
        }

        var gpsPoint =
            GeometryUtils.point(
                info.longitude,
                info.latitude
            )

        var usuarioPunto =
            GeometryUtils.reprojectPoint(
                gpsPoint,
                CoordinateReferenceSystemUtils.wgs84Crs(),
                qgisProject.crs
            )

        var contadorPunto =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs
            )

        var it =
            LayerUtils.createFeatureIterator(
                caminoNodosLayer
            )

        var distanciaUsuarioMinima =
            Number.POSITIVE_INFINITY

        var distanciaDestinoMinima =
            Number.POSITIVE_INFINITY

        var fidUsuario = null
        var fidDestino = null

        while (it.hasNext()) {

            var nodo = it.next()

            var nodoPunto =
                GeometryUtils.centroid(
                    nodo.geometry
                )

            var nodoPuntoMapa =
                GeometryUtils.reprojectPoint(
                    nodoPunto,
                    caminoNodosLayer.crs,
                    qgisProject.crs
                )

            var distanciaUsuario =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    usuarioPunto
                )

            if (
                distanciaUsuario <
                distanciaUsuarioMinima
            ) {

                distanciaUsuarioMinima =
                    distanciaUsuario

                fidUsuario =
                    nodo.attribute("fid")
            }

            var distanciaDestino =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    contadorPunto
                )

            if (
                distanciaDestino <
                distanciaDestinoMinima
            ) {

                distanciaDestinoMinima =
                    distanciaDestino

                fidDestino =
                    nodo.attribute("fid")
            }
        }

        nodoUsuarioFid = fidUsuario
        nodoDestinoFid = fidDestino

        if (
            fidUsuario === null ||
            fidDestino === null
        ) {

            iface.mainWindow().displayToast(
                "No se pudieron encontrar los nodos"
            )

            return
        }

        iface.mainWindow().displayToast(
            "Usuario → nodo FID: " +
            fidUsuario +
            " | Destino → nodo FID: " +
            fidDestino
        )

        buscarRuta(
            fidUsuario,
            fidDestino
        )
    }

    function buscarRuta(inicioFid, destinoFid) {

        caminoLineasLayer =
            qgisProject.mapLayersByName(
                "CAMINO LINEAS"
            )[0]

        if (!caminoLineasLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa CAMINO LINEAS"
            )

            return
        }

        rutaActivaLayer =
            qgisProject.mapLayersByName(
                "RUTA ACTIVA"
            )[0]

        if (!rutaActivaLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa RUTA ACTIVA"
            )

            return
        }

        // ------------------------------------------------
        // CONSTRUIR EL GRAFO
        // ------------------------------------------------

        var conexiones = {}

        var it =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        while (it.hasNext()) {

            var linea = it.next()

            var nodo1 =
                String(
                    linea.attribute("nodo1")
                )

            var nodo2 =
                String(
                    linea.attribute("nodo2")
                )

            if (!conexiones[nodo1]) {
                conexiones[nodo1] = []
            }

            if (!conexiones[nodo2]) {
                conexiones[nodo2] = []
            }

            conexiones[nodo1].push({
                nodo: nodo2,
                fid: linea.attribute("fid")
            })

            conexiones[nodo2].push({
                nodo: nodo1,
                fid: linea.attribute("fid")
            })
        }

        // ------------------------------------------------
        // BUSQUEDA EN ANCHURA
        // ------------------------------------------------

        var inicio =
            String(inicioFid)

        var destino =
            String(destinoFid)

        var cola = [inicio]

        var visitados = {}
        var anterior = {}
        var lineaAnterior = {}

        visitados[inicio] = true

        var encontrado = false

        while (
            cola.length > 0 &&
            !encontrado
        ) {

            var actual =
                cola.shift()

            if (actual === destino) {

                encontrado = true
                break
            }

            var vecinos =
                conexiones[actual]

            if (!vecinos) {
                continue
            }

            for (
                var i = 0;
                i < vecinos.length;
                i++
            ) {

                var vecino =
                    vecinos[i].nodo

                if (!visitados[vecino]) {

                    visitados[vecino] = true

                    anterior[vecino] =
                        actual

                    lineaAnterior[vecino] =
                        vecinos[i].fid

                    cola.push(vecino)
                }
            }
        }

        if (!encontrado) {

            iface.mainWindow().displayToast(
                "No existe un recorrido entre los nodos"
            )

            return
        }

        // ------------------------------------------------
        // RECONSTRUIR LA RUTA
        // ------------------------------------------------

        var nodosRuta = []
        var lineasRuta = []

        var actualRuta =
            destino

        while (
            actualRuta !== inicio
        ) {

            nodosRuta.unshift(
                actualRuta
            )

            lineasRuta.unshift(
                lineaAnterior[actualRuta]
            )

            actualRuta =
                anterior[actualRuta]
        }

        nodosRuta.unshift(inicio)

        // ------------------------------------------------
        // MOSTRAR RESULTADO
        // ------------------------------------------------

        iface.mainWindow().displayToast(
            "Ruta encontrada: " +
            lineasRuta.length +
            " tramos"
        )

        rellenarRutaActiva(
            lineasRuta
        )
    }

    function rellenarRutaActiva(lineasRuta) {

        // ------------------------------------------------
        // LIMPIAR RUTA ACTIVA ANTERIOR
        // ------------------------------------------------

        var it =
            LayerUtils.createFeatureIterator(
                rutaActivaLayer
            )

        var fidsEliminar = []

        while (it.hasNext()) {

            var feature = it.next()

            fidsEliminar.push(
                feature.id
            )
        }

        for (
            var i = 0;
            i < fidsEliminar.length;
            i++
        ) {

            QfLayerUtils.deleteFeature(
                qgisProject,
                rutaActivaLayer,
                fidsEliminar[i]
            )
        }

        // ------------------------------------------------
        // COPIAR LAS LÍNEAS DE LA RUTA
        // ------------------------------------------------

        var itLineas =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        var lineasEncontradas = {}

        while (itLineas.hasNext()) {

            var linea =
                itLineas.next()

            var fid =
                String(
                    linea.attribute("fid")
                )

            lineasEncontradas[fid] =
                linea
        }

        // ------------------------------------------------
        // AÑADIR CADA TRAMO A RUTA ACTIVA
        // ------------------------------------------------

        for (
            var j = 0;
            j < lineasRuta.length;
            j++
        ) {

            var lineaOriginal =
                lineasEncontradas[
                    String(lineasRuta[j])
                ]

            if (!lineaOriginal) {
                continue
            }

            var nuevaFeature =
                FeatureUtils.createFeature(
                    rutaActivaLayer,
                    lineaOriginal.geometry
                )

            QfLayerUtils.addFeature(
                rutaActivaLayer,
                nuevaFeature
            )
        }

        iface.mainWindow().displayToast(
            "RUTA ACTIVA rellenada"
        )
    }

    QfToolButton {
        id: botonRuta

        iconSource:
            Theme.getThemeVectorIcon(
                "ic_navigation_white_24dp"
            )

        iconColor:
            Theme.toolButtonColor

        bgcolor:
            Theme.toolButtonBackgroundColor

        round: true

        onClicked: {

            cargarContadores()

            actualizarLista()

            selectorContador.open()
        }
    }

    QfDialog {
        id: selectorContador

        parent:
            iface.mainWindow().contentItem

        width:
            Math.min(
                500,
                iface.mainWindow().width - 40
            )

        height:
            Math.min(
                700,
                iface.mainWindow().height - 40
            )

        x:
            (iface.mainWindow().width - width) / 2

        y:
            (iface.mainWindow().height - height) / 2

        title: "Seleccionar contador"

        Column {
            anchors.fill: parent
            anchors.margins: 16

            spacing: 10

            TextField {
                id: buscador

                width: parent.width

                placeholderText:
                    "Buscar contador..."

                onTextChanged: {
                    actualizarLista()
                }
            }

            ListView {
                id: lista

                width: parent.width

                height:
                    parent.height -
                    buscador.height -
                    10

                clip: true

                model: listaModelo

                delegate: ItemDelegate {

                    width: lista.width

                    text: model.nombre

                    onClicked: {

                        seleccionarContador(
                            model.id
                        )
                    }
                }
            }
        }
    }

    ListModel {
        id: listaModelo
    }

    Component.onCompleted: {

        iface.addItemToPluginsToolbar(
            botonRuta
        )

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}