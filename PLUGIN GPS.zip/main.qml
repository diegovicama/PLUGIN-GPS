import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    QfToolButton {
        id: botonRuta

        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: {
            iface.mainWindow().displayToast(
                "Abrir selección de contador"
            )
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(botonRuta)

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}