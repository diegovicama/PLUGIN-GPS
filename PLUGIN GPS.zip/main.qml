import QtQuick
import QtQuick.Controls
import org.qfield

Item {
    id: plugin

    property var contadoresLayer: null
    property var contadores: []
    property var contadoresFiltrados: []

    function mostrarMensaje(texto) {
        iface.mainWindow().displayToast(texto)
    }

    function cargarContadores() {
        contadoresLayer = qgisProject.mapLayersByName("CONTADORES")[0]

        if (!contadoresLayer) {
            mostrarMensaje("No se encontró la capa CONTADORES")
            return
        }

        var features = contadoresLayer.getFeatures()
        contadores = []

        for (var feature of features) {
            contadores.push({
                nombre: feature.attribute("NOMBRE"),
                id: feature.id()
            })
        }

        contadoresFiltrados = contadores
    }

    function filtrarContadores(texto) {
        var resultado = []

        for (var i = 0; i < contadores.length; i++) {
            var nombre = String(contadores[i].nombre)

            if (nombre.toLowerCase().indexOf(texto.toLowerCase()) !== -1) {
                resultado.push(contadores[i])
            }
        }

        contadoresFiltrados = resultado
    }

    Component.onCompleted: {
        cargarContadores()
        selector.open()
    }

    Dialog {
        id: selector

        title: "Seleccionar contador"
        modal: true

        width: Math.min(parent.width - 40, 500)
        height: Math.min(parent.height - 40, 700)

        anchors.centerIn: parent

        Column {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            TextField {
                id: buscador

                width: parent.width

                placeholderText: "Buscar contador..."

                onTextChanged: {
                    filtrarContadores(text)
                }
            }

            ListView {
                id: lista

                width: parent.width
                height: parent.height - buscador.height - 10

                clip: true

                model: contadoresFiltrados

                delegate: ItemDelegate {
                    width: lista.width
                    text: modelData.nombre

                    onClicked: {
                        selector.close()

                        mostrarMensaje(
                            "Contador seleccionado: " +
                            modelData.nombre
                        )
                    }
                }
            }
        }
    }
}