import QtQuick
import org.qfield

Item {
    id: plugin

    QfToolButton {
        id: botonRuta

        iconSource: "qrc:/qml/images/navigation.svg"

        onClicked: {
            iface.mainWindow().displayToast(
                "Abrir selección de contador"
            )
        }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(botonRuta)

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}