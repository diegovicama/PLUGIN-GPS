import QtQuick
import org.qfield

Item {
    Component.onCompleted: {
        iface.mainWindow().displayToast("Plugin de rutas funcionando")
    }
}