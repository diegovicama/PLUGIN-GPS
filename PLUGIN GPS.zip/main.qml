import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var contadoresLayer: null
    property var listaContadores: []

    function cargarContadores() {
        contadoresLayer = qgisProject.mapLayersByName("CONTADORES")[0]

        if (!contadoresLayer) {
            iface.mainWindow().displayToast(
                "No se encontró la capa CONTADORES"
            )
            return
        }

        var lista = []
        var features = contadoresLayer.getFeatures()

        for (var feature of features) {
            lista.push({
                nombre: String(feature.attribute("NOMBRE")),
                id: feature.id()
            })
        }

        listaContadores = lista
    }

    function filtrarContadores() {
        var texto = buscador.text.toLowerCase()
        var resultado = []

        for (var i = 0; i < listaContadores.length; i++) {
            var nombre = listaContadores[i].nombre

            if (nombre.toLowerCase().indexOf(texto) !== -1) {
                resultado.push(listaContadores[i])
            }
        }

        listaModelo.clear()

        for (var j = 0; j < resultado.length; j++) {
            listaModelo.append(resultado[j])
        }
    }

    QfToolButton {
        id: botonRuta

        iconSource: Theme.getThemeVectorIcon("ic_navigation_white_24dp")
        iconColor: Theme.toolButtonColor
        bgcolor: Theme.toolButtonBackgroundColor
        round: true

        onClicked: {
            cargarContadores()
            filtrarContadores()
            selectorContador.open()
        }
    }

    QfDialog {
        id: selectorContador

        parent: iface.mainWindow().contentItem

        width: Math.min(500, iface.mainWindow().width - 40)
        height: Math.min(700, iface.mainWindow().height - 40)

        x: (iface.mainWindow().width - width) / 2
        y: (iface.mainWindow().height - height) / 2

        title: "Seleccionar contador"

        Column {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            TextField {
                id: buscador

                width: parent.width

                placeholderText: "Buscar contador..."

                onTextChanged: {
                    filtrarContadores()
                }
            }

            ListView {
                id: lista

                width: parent.width
                height: parent.height - buscador.height - 10

                clip: true

                model: listaModelo

                delegate: ItemDelegate {
                    width: lista.width

                    text: model.nombre

                    onClicked: {
                        selectorContador.close()

                        iface.mainWindow().displayToast(
                            "Seleccionado: " + model.nombre
                        )
                    }
                }
            }
        }
    }

    ListModel {
        id: listaModelo
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(botonRuta)

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}