import QtQuick
import org.qfield

Item {
    Component.onCompleted: {
        iface.mainWindow().displayToast("Plugin cargado")

        console.log("Proyecto:", qgisProject)
    }
}