import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    property var contadoresLayer: null
    property var caminoNodosLayer: null
    property var caminoLineasLayer: null

    property var listaContadores: []

    // Contador seleccionado
    property var destinoId: null
    property var destinoNombre: ""
    property var destinoGeometria: null
    property var destinoPunto: null

    // Nodos encontrados
    property var nodoUsuarioFid: null
    property var nodoDestinoFid: null


    // ============================================================
    // CARGAR CONTADORES
    // ============================================================

    function cargarContadores() {

        contadoresLayer =
            qgisProject.mapLayersByName(
                "CONTADORES"
            )[0]

        if (!contadoresLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa CONTADORES"
            )

            return
        }

        var lista = []

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var feature = it.next()

            lista.push({
                nombre: String(
                    feature.attribute("NOMBRE")
                ),
                id: feature.id
            })
        }

        listaContadores = lista
    }


    // ============================================================
    // ACTUALIZAR LISTA DE CONTADORES
    // ============================================================

    function actualizarLista() {

        var texto =
            buscador.text.toLowerCase()

        listaModelo.clear()

        for (
            var i = 0;
            i < listaContadores.length;
            i++
        ) {

            var nombre =
                listaContadores[i].nombre

            if (
                texto === "" ||
                nombre.toLowerCase().indexOf(texto) !== -1
            ) {

                listaModelo.append({
                    nombre: nombre,
                    id: listaContadores[i].id
                })
            }
        }
    }


    // ============================================================
    // SELECCIONAR CONTADOR
    // ============================================================

    function seleccionarContador(featureId) {

        if (!contadoresLayer) {
            return
        }

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var feature = it.next()

            if (feature.id === featureId) {

                destinoId =
                    feature.id

                destinoNombre =
                    String(
                        feature.attribute("NOMBRE")
                    )

                destinoGeometria =
                    feature.geometry

                destinoPunto =
                    GeometryUtils.centroid(
                        feature.geometry
                    )

                var puntoMapa =
                    GeometryUtils.reprojectPoint(
                        destinoPunto,
                        contadoresLayer.crs,
                        qgisProject.crs
                    )

                iface.mapCanvas().mapSettings.center =
                    puntoMapa

                selectorContador.close()

                buscarNodosMasCercanos()

                return
            }
        }

        iface.mainWindow().displayToast(
            "No se encontró el contador seleccionado"
        )
    }


    // ============================================================
    // BUSCAR NODOS MÁS CERCANOS
    // ============================================================

    function buscarNodosMasCercanos() {

        caminoNodosLayer =
            qgisProject.mapLayersByName(
                "CAMINO NODOS"
            )[0]

        if (!caminoNodosLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa CAMINO NODOS"
            )

            return
        }

        var positioning =
            iface.findItemByObjectName(
                "positionSource"
            )

        if (!positioning) {

            iface.mainWindow().displayToast(
                "No se encontró el GPS de QField"
            )

            return
        }

        if (!positioning.active) {

            iface.mainWindow().displayToast(
                "El GPS de QField no está activo"
            )

            return
        }

        var info =
            positioning.positionInformation

        if (
            !info.longitudeValid ||
            !info.latitudeValid
        ) {

            iface.mainWindow().displayToast(
                "La posición GPS todavía no es válida"
            )

            return
        }

        var gpsPoint =
            GeometryUtils.point(
                info.longitude,
                info.latitude
            )

        var usuarioPunto =
            GeometryUtils.reprojectPoint(
                gpsPoint,
                CoordinateReferenceSystemUtils.wgs84Crs(),
                qgisProject.crs
            )

        var contadorPunto =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs
            )

        var it =
            LayerUtils.createFeatureIterator(
                caminoNodosLayer
            )

        var distanciaUsuarioMinima =
            Number.POSITIVE_INFINITY

        var distanciaDestinoMinima =
            Number.POSITIVE_INFINITY

        var fidUsuario = null
        var fidDestino = null

        while (it.hasNext()) {

            var nodo = it.next()

            var nodoPunto =
                GeometryUtils.centroid(
                    nodo.geometry
                )

            var nodoPuntoMapa =
                GeometryUtils.reprojectPoint(
                    nodoPunto,
                    caminoNodosLayer.crs,
                    qgisProject.crs
                )

            var distanciaUsuario =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    usuarioPunto
                )

            if (
                distanciaUsuario <
                distanciaUsuarioMinima
            ) {

                distanciaUsuarioMinima =
                    distanciaUsuario

                fidUsuario =
                    nodo.attribute("fid")
            }

            var distanciaDestino =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    contadorPunto
                )

            if (
                distanciaDestino <
                distanciaDestinoMinima
            ) {

                distanciaDestinoMinima =
                    distanciaDestino

                fidDestino =
                    nodo.attribute("fid")
            }
        }

        nodoUsuarioFid =
            fidUsuario

        nodoDestinoFid =
            fidDestino

        if (
            fidUsuario === null ||
            fidDestino === null
        ) {

            iface.mainWindow().displayToast(
                "No se pudieron encontrar los nodos"
            )

            return
        }

        iface.mainWindow().displayToast(
            "Usuario → nodo FID: " +
            fidUsuario +
            " | Destino → nodo FID: " +
            fidDestino
        )

        buscarRuta(
            fidUsuario,
            fidDestino
        )
    }


    // ============================================================
    // BUSCAR RUTA
    // ============================================================

    function buscarRuta(
        inicioFid,
        destinoFid
    ) {

        caminoLineasLayer =
            qgisProject.mapLayersByName(
                "CAMINO LINEAS"
            )[0]

        if (!caminoLineasLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa CAMINO LINEAS"
            )

            return
        }

        // --------------------------------------------------------
        // CONSTRUIR GRAFO
        // --------------------------------------------------------

        var conexiones = {}

        var it =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        while (it.hasNext()) {

            var linea = it.next()

            var nodo1 =
                String(
                    linea.attribute("nodo1")
                )

            var nodo2 =
                String(
                    linea.attribute("nodo2")
                )

            if (!conexiones[nodo1]) {
                conexiones[nodo1] = []
            }

            if (!conexiones[nodo2]) {
                conexiones[nodo2] = []
            }

            conexiones[nodo1].push({
                nodo: nodo2,
                fid: linea.attribute("fid")
            })

            conexiones[nodo2].push({
                nodo: nodo1,
                fid: linea.attribute("fid")
            })
        }


        // --------------------------------------------------------
        // BÚSQUEDA EN ANCHURA
        // --------------------------------------------------------

        var inicio =
            String(inicioFid)

        var destino =
            String(destinoFid)

        var cola = [inicio]

        var visitados = {}
        var anterior = {}
        var lineaAnterior = {}

        visitados[inicio] = true

        var encontrado = false

        while (
            cola.length > 0 &&
            !encontrado
        ) {

            var actual =
                cola.shift()

            if (actual === destino) {

                encontrado = true

                break
            }

            var vecinos =
                conexiones[actual]

            if (!vecinos) {
                continue
            }

            for (
                var i = 0;
                i < vecinos.length;
                i++
            ) {

                var vecino =
                    vecinos[i].nodo

                if (!visitados[vecino]) {

                    visitados[vecino] = true

                    anterior[vecino] =
                        actual

                    lineaAnterior[vecino] =
                        vecinos[i].fid

                    cola.push(vecino)
                }
            }
        }


        // --------------------------------------------------------
        // NO HAY RUTA
        // --------------------------------------------------------

        if (!encontrado) {

            iface.mainWindow().displayToast(
                "No existe un recorrido entre los nodos"
            )

            return
        }


        // --------------------------------------------------------
        // RECONSTRUIR RUTA
        // --------------------------------------------------------

        var lineasRuta = []

        var actualRuta =
            destino

        while (
            actualRuta !== inicio
        ) {

            lineasRuta.unshift(
                lineaAnterior[actualRuta]
            )

            actualRuta =
                anterior[actualRuta]
        }


        // --------------------------------------------------------
        // MOSTRAR RESULTADO
        // --------------------------------------------------------

        iface.mainWindow().displayToast(
            "Ruta encontrada: " +
            lineasRuta.length +
            " tramos"
        )


        // --------------------------------------------------------
        // ACTIVAR RUTA VISUAL
        // --------------------------------------------------------

        visualizarRuta(
            lineasRuta
        )
    }


    // ============================================================
    // VISUALIZAR RUTA
    // ============================================================

    function visualizarRuta(lineasRuta) {

        if (!caminoLineasLayer) {

            iface.mainWindow().displayToast(
                "No se encontró CAMINO LINEAS"
            )

            return
        }

        // --------------------------------------------------------
        // BUSCAR CAMPO VISUALIZAR
        // --------------------------------------------------------

        var indiceVisualizar =
            caminoLineasLayer.fields.indexOf(
                "VISUALIZAR"
            )

        if (indiceVisualizar < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo VISUALIZAR"
            )

            return
        }


        // --------------------------------------------------------
        // CREAR LISTA DE FID DE LA RUTA
        // --------------------------------------------------------

        var rutaFids = {}

        for (
            var i = 0;
            i < lineasRuta.length;
            i++
        ) {

            rutaFids[
                String(lineasRuta[i])
            ] = true
        }


        // --------------------------------------------------------
        // PONER CAPA EN EDICIÓN
        // --------------------------------------------------------

        if (
            !caminoLineasLayer.startEditing()
        ) {

            iface.mainWindow().displayToast(
                "No se pudo poner CAMINO LINEAS en edición"
            )

            return
        }


        // --------------------------------------------------------
        // CAMBIAR VISUALIZAR
        // --------------------------------------------------------

        var it =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        var activadas = 0
        var desactivadas = 0

        while (it.hasNext()) {

            var linea = it.next()

            var fid =
                String(
                    linea.attribute("fid")
                )

            var activar =
                rutaFids[fid] === true

            var valor =
                activar

            var resultado =
                caminoLineasLayer.changeAttributeValue(
                    linea.id,
                    indiceVisualizar,
                    valor
                )

            if (resultado) {

                if (activar) {
                    activadas++
                } else {
                    desactivadas++
                }

            } else {

                console.log(
                    "No se pudo modificar FID " +
                    fid
                )
            }
        }


        // --------------------------------------------------------
        // GUARDAR CAMBIOS
        // --------------------------------------------------------

        var guardado =
            caminoLineasLayer.commitChanges()

        if (!guardado) {

            iface.mainWindow().displayToast(
                "Error guardando VISUALIZAR"
            )

            return
        }


        // --------------------------------------------------------
        // ACTUALIZAR MAPA
        // --------------------------------------------------------

        caminoLineasLayer.triggerRepaint()

        iface.mainWindow().displayToast(
            "Ruta visualizada: " +
            activadas +
            " líneas"
        )
    }


    // ============================================================
    // BOTÓN
    // ============================================================

    QfToolButton {
        id: botonRuta

        iconSource:
            Theme.getThemeVectorIcon(
                "ic_navigation_white_24dp"
            )

        iconColor:
            Theme.toolButtonColor

        bgcolor:
            Theme.toolButtonBackgroundColor

        round: true

        onClicked: {

            cargarContadores()

            actualizarLista()

            selectorContador.open()
        }
    }


    // ============================================================
    // SELECTOR DE CONTADOR
    // ============================================================

    QfDialog {

        id: selectorContador

        parent:
            iface.mainWindow().contentItem

        width:
            Math.min(
                500,
                iface.mainWindow().width - 40
            )

        height:
            Math.min(
                700,
                iface.mainWindow().height - 40
            )

        x:
            (iface.mainWindow().width - width) / 2

        y:
            (iface.mainWindow().height - height) / 2

        title:
            "Seleccionar contador"

        Column {

            anchors.fill: parent

            anchors.margins: 16

            spacing: 10

            TextField {

                id: buscador

                width:
                    parent.width

                placeholderText:
                    "Buscar contador..."

                onTextChanged: {
                    actualizarLista()
                }
            }

            ListView {

                id: lista

                width:
                    parent.width

                height:
                    parent.height -
                    buscador.height -
                    10

                clip: true

                model:
                    listaModelo

                delegate:
                    ItemDelegate {

                    width:
                        lista.width

                    text:
                        model.nombre

                    onClicked: {

                        seleccionarContador(
                            model.id
                        )
                    }
                }
            }
        }
    }


    // ============================================================
    // MODELO
    // ============================================================

    ListModel {
        id: listaModelo
    }


    // ============================================================
    // INICIO
    // ============================================================

    Component.onCompleted: {

        iface.addItemToPluginsToolbar(
            botonRuta
        )

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}