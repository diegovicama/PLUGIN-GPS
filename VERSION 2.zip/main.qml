```qml
import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
    id: plugin

    // ============================================================
    // CONFIGURACIÓN
    // ============================================================

    // Nombres de capas
    property string nombreCapaContadores:
        "CONTADORES LOS PINOS"

    property string nombreCapaNodos:
        "CAMINO NODOS"

    property string nombreCapaLineas:
        "CAMINO LINEAS"


    // Campos de CONTADORES LOS PINOS
    property string campoContador:
        "Nº CONTADOR"

    property string campoSeleccionado:
        "SELECCIONADO"


    // Campos de CAMINO NODOS
    property string campoNodoFid:
        "fid"


    // Campos de CAMINO LINEAS
    property string campoLineaFid:
        "fid"

    property string campoNodo1:
        "nodo1"

    property string campoNodo2:
        "nodo2"

    property string campoLongitud:
        "LONGITUD"

    property string campoVisualizar:
        "VISUALIZAR"


    // ============================================================
    // CAPAS
    // ============================================================

    property var contadoresLayer: null
    property var caminoNodosLayer: null
    property var caminoLineasLayer: null


    // ============================================================
    // LISTA DE CONTADORES
    // ============================================================

    property var listaContadores: []


    // ============================================================
    // CONTADOR SELECCIONADO
    // ============================================================

    property var destinoId: null
    property var destinoNombre: ""
    property var destinoGeometria: null
    property var destinoPunto: null


    // ============================================================
    // NODOS ENCONTRADOS
    // ============================================================

    property var nodoUsuarioFid: null
    property var nodoDestinoFid: null


    // ============================================================
    // ESTADO DE LA RUTA
    // ============================================================

    property bool rutaActiva: false


    // ============================================================
    // RED DE CAMINOS
    // ============================================================

    /*
     * La red se construye una sola vez.
     *
     * Ejemplo:
     *
     * redCaminos["15"] = [
     *     {
     *         nodo: "16",
     *         fid: 123,
     *         distancia: 12.45
     *     }
     * ]
     */

    property var redCaminos: ({})
    property bool redCaminosCargada: false


    // ============================================================
    // CARGAR CONTADORES
    // ============================================================

    function cargarContadores() {

        contadoresLayer =
            qgisProject.mapLayersByName(
                nombreCapaContadores
            )[0]

        if (!contadoresLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa " +
                nombreCapaContadores
            )

            return
        }

        var lista = []

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var feature = it.next()

            lista.push({
                nombre: String(
                    feature.attribute(
                        campoContador
                    )
                ),
                id: feature.id
            })
        }

        listaContadores = lista
    }


    // ============================================================
    // ACTUALIZAR LISTA DE CONTADORES
    // ============================================================

    function actualizarLista() {

        var texto =
            buscador.text.toLowerCase()

        listaModelo.clear()

        for (
            var i = 0;
            i < listaContadores.length;
            i++
        ) {

            var nombre =
                listaContadores[i].nombre

            if (
                texto === "" ||
                nombre.toLowerCase().indexOf(texto) !== -1
            ) {

                listaModelo.append({
                    nombre: nombre,
                    id: listaContadores[i].id
                })
            }
        }
    }


    // ============================================================
    // CARGAR RED DE CAMINOS
    // ============================================================

    function cargarRedCaminos() {

        if (redCaminosCargada) {
            return true
        }

        caminoLineasLayer =
            qgisProject.mapLayersByName(
                nombreCapaLineas
            )[0]

        if (!caminoLineasLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa " +
                nombreCapaLineas
            )

            return false
        }


        // --------------------------------------------------------
        // COMPROBAR CAMPOS
        // --------------------------------------------------------

        var indiceFid =
            caminoLineasLayer.fields.indexOf(
                campoLineaFid
            )

        var indiceNodo1 =
            caminoLineasLayer.fields.indexOf(
                campoNodo1
            )

        var indiceNodo2 =
            caminoLineasLayer.fields.indexOf(
                campoNodo2
            )

        var indiceLongitud =
            caminoLineasLayer.fields.indexOf(
                campoLongitud
            )

        var indiceVisualizar =
            caminoLineasLayer.fields.indexOf(
                campoVisualizar
            )


        if (indiceFid < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoLineaFid
            )

            return false
        }

        if (indiceNodo1 < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoNodo1
            )

            return false
        }

        if (indiceNodo2 < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoNodo2
            )

            return false
        }

        if (indiceLongitud < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoLongitud
            )

            return false
        }

        if (indiceVisualizar < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoVisualizar
            )

            return false
        }


        // --------------------------------------------------------
        // CREAR RED
        // --------------------------------------------------------

        var conexiones = {}

        var it =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        while (it.hasNext()) {

            var linea = it.next()

            var nodo1 =
                String(
                    linea.attribute(
                        campoNodo1
                    )
                )

            var nodo2 =
                String(
                    linea.attribute(
                        campoNodo2
                    )
                )

            var fid =
                Number(
                    linea.attribute(
                        campoLineaFid
                    )
                )

            var distancia =
                Number(
                    linea.attribute(
                        campoLongitud
                    )
                )


            // ----------------------------------------------------
            // COMPROBAR LONGITUD
            // ----------------------------------------------------

            if (
                !isFinite(distancia) ||
                distancia < 0
            ) {

                iface.mainWindow().displayToast(
                    "Longitud no válida en la línea FID " +
                    fid
                )

                return false
            }


            // ----------------------------------------------------
            // CREAR NODOS DE LA RED
            // ----------------------------------------------------

            if (!conexiones[nodo1]) {
                conexiones[nodo1] = []
            }

            if (!conexiones[nodo2]) {
                conexiones[nodo2] = []
            }


            // ----------------------------------------------------
            // RED BIDIRECCIONAL
            // ----------------------------------------------------

            conexiones[nodo1].push({
                nodo: nodo2,
                fid: fid,
                distancia: distancia
            })

            conexiones[nodo2].push({
                nodo: nodo1,
                fid: fid,
                distancia: distancia
            })
        }


        redCaminos =
            conexiones

        redCaminosCargada =
            true

        return true
    }


    // ============================================================
    // MARCAR CONTADOR SELECCIONADO
    // ============================================================

    function marcarContadorSeleccionado(featureId) {

        if (!contadoresLayer) {
            return false
        }

        var indiceSeleccionado =
            contadoresLayer.fields.indexOf(
                campoSeleccionado
            )

        if (indiceSeleccionado < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoSeleccionado
            )

            return false
        }

        if (
            !contadoresLayer.startEditing()
        ) {

            iface.mainWindow().displayToast(
                "No se pudo editar " +
                nombreCapaContadores
            )

            return false
        }

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var contador = it.next()

            var seleccionado =
                contador.id === featureId

            contadoresLayer.changeAttributeValue(
                contador.id,
                indiceSeleccionado,
                seleccionado
            )
        }

        var guardado =
            contadoresLayer.commitChanges()

        if (!guardado) {

            iface.mainWindow().displayToast(
                "Error guardando " +
                campoSeleccionado
            )

            return false
        }

        contadoresLayer.triggerRepaint()

        return true
    }


    // ============================================================
    // SELECCIONAR CONTADOR
    // ============================================================

    function seleccionarContador(featureId) {

        if (!contadoresLayer) {
            return
        }


        // --------------------------------------------------------
        // CARGAR RED SI TODAVÍA NO ESTÁ CARGADA
        // --------------------------------------------------------

        if (!cargarRedCaminos()) {
            return
        }


        // --------------------------------------------------------
        // BUSCAR CONTADOR
        // --------------------------------------------------------

        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )

        while (it.hasNext()) {

            var feature = it.next()

            if (feature.id === featureId) {

                destinoId =
                    feature.id

                destinoNombre =
                    String(
                        feature.attribute(
                            campoContador
                        )
                    )

                destinoGeometria =
                    feature.geometry

                destinoPunto =
                    GeometryUtils.centroid(
                        feature.geometry
                    )


                // ------------------------------------------------
                // MARCAR CONTADOR
                // ------------------------------------------------

                if (
                    !marcarContadorSeleccionado(
                        feature.id
                    )
                ) {

                    return
                }


                // ------------------------------------------------
                // CENTRAR MAPA
                // ------------------------------------------------

                var puntoMapa =
                    GeometryUtils.reprojectPoint(
                        destinoPunto,
                        contadoresLayer.crs,
                        qgisProject.crs
                    )

                iface.mapCanvas().mapSettings.center =
                    puntoMapa


                selectorContador.close()


                // ------------------------------------------------
                // BUSCAR NODOS
                // ------------------------------------------------

                buscarNodosMasCercanos()

                return
            }
        }

        iface.mainWindow().displayToast(
            "No se encontró el contador seleccionado"
        )
    }


    // ============================================================
    // BUSCAR NODOS MÁS CERCANOS
    // ============================================================

    function buscarNodosMasCercanos() {

        caminoNodosLayer =
            qgisProject.mapLayersByName(
                nombreCapaNodos
            )[0]

        if (!caminoNodosLayer) {

            iface.mainWindow().displayToast(
                "No se encontró la capa " +
                nombreCapaNodos
            )

            return
        }


        // --------------------------------------------------------
        // GPS
        // --------------------------------------------------------

        var positioning =
            iface.findItemByObjectName(
                "positionSource"
            )

        if (!positioning) {

            iface.mainWindow().displayToast(
                "No se encontró el GPS de QField"
            )

            return
        }

        if (!positioning.active) {

            iface.mainWindow().displayToast(
                "El GPS de QField no está activo"
            )

            return
        }

        var info =
            positioning.positionInformation

        if (
            !info.longitudeValid ||
            !info.latitudeValid
        ) {

            iface.mainWindow().displayToast(
                "La posición GPS todavía no es válida"
            )

            return
        }


        // --------------------------------------------------------
        // PUNTO GPS
        // --------------------------------------------------------

        var gpsPoint =
            GeometryUtils.point(
                info.longitude,
                info.latitude
            )

        var usuarioPunto =
            GeometryUtils.reprojectPoint(
                gpsPoint,
                CoordinateReferenceSystemUtils.wgs84Crs(),
                qgisProject.crs
            )


        // --------------------------------------------------------
        // PUNTO DEL CONTADOR
        // --------------------------------------------------------

        var contadorPunto =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs
            )


        // --------------------------------------------------------
        // BUSCAR NODOS
        // --------------------------------------------------------

        var it =
            LayerUtils.createFeatureIterator(
                caminoNodosLayer
            )

        var distanciaUsuarioMinima =
            Number.POSITIVE_INFINITY

        var distanciaDestinoMinima =
            Number.POSITIVE_INFINITY

        var fidUsuario = null
        var fidDestino = null


        while (it.hasNext()) {

            var nodo = it.next()

            var nodoPunto =
                GeometryUtils.centroid(
                    nodo.geometry
                )

            var nodoPuntoMapa =
                GeometryUtils.reprojectPoint(
                    nodoPunto,
                    caminoNodosLayer.crs,
                    qgisProject.crs
                )


            // ----------------------------------------------------
            // DISTANCIA AL USUARIO
            // ----------------------------------------------------

            var distanciaUsuario =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    usuarioPunto
                )

            if (
                distanciaUsuario <
                distanciaUsuarioMinima
            ) {

                distanciaUsuarioMinima =
                    distanciaUsuario

                fidUsuario =
                    nodo.attribute(
                        campoNodoFid
                    )
            }


            // ----------------------------------------------------
            // DISTANCIA AL DESTINO
            // ----------------------------------------------------

            var distanciaDestino =
                GeometryUtils.distanceBetweenPoints(
                    nodoPuntoMapa,
                    contadorPunto
                )

            if (
                distanciaDestino <
                distanciaDestinoMinima
            ) {

                distanciaDestinoMinima =
                    distanciaDestino

                fidDestino =
                    nodo.attribute(
                        campoNodoFid
                    )
            }
        }


        nodoUsuarioFid =
            fidUsuario

        nodoDestinoFid =
            fidDestino


        if (
            fidUsuario === null ||
            fidDestino === null
        ) {

            iface.mainWindow().displayToast(
                "No se pudieron encontrar los nodos"
            )

            return
        }


        iface.mainWindow().displayToast(
            "Usuario → nodo FID: " +
            fidUsuario +
            " | Destino → nodo FID: " +
            fidDestino
        )


        buscarRuta(
            fidUsuario,
            fidDestino
        )
    }


    // ============================================================
    // BUSCAR RUTA - DIJKSTRA
    // ============================================================

    function buscarRuta(
        inicioFid,
        destinoFid
    ) {

        // --------------------------------------------------------
        // COMPROBAR RED
        // --------------------------------------------------------

        if (!redCaminosCargada) {

            if (!cargarRedCaminos()) {
                return
            }
        }


        // --------------------------------------------------------
        // CONVERTIR FID A TEXTO
        // --------------------------------------------------------

        var inicio =
            String(inicioFid)

        var destino =
            String(destinoFid)


        // --------------------------------------------------------
        // CASO: MISMO NODO
        // --------------------------------------------------------

        if (inicio === destino) {

            iface.mainWindow().displayToast(
                "Usuario y destino están en el mismo nodo"
            )

            visualizarRuta([])

            return
        }


        // --------------------------------------------------------
        // ESTRUCTURAS DE DIJKSTRA
        // --------------------------------------------------------

        var distancias = {}
        var anterior = {}
        var lineaAnterior = {}
        var visitados = {}

        var nodosPendientes = []


        // --------------------------------------------------------
        // DISTANCIA INICIAL
        // --------------------------------------------------------

        distancias[inicio] = 0

        nodosPendientes.push({
            nodo: inicio,
            distancia: 0
        })


        var encontrado = false


        // --------------------------------------------------------
        // BÚSQUEDA DIJKSTRA
        // --------------------------------------------------------

        while (
            nodosPendientes.length > 0
        ) {


            // ----------------------------------------------------
            // ENCONTRAR NODO PENDIENTE CON MENOR DISTANCIA
            // ----------------------------------------------------

            var indiceMenor = 0

            for (
                var i = 1;
                i < nodosPendientes.length;
                i++
            ) {

                if (
                    nodosPendientes[i].distancia <
                    nodosPendientes[indiceMenor].distancia
                ) {

                    indiceMenor = i
                }
            }


            // ----------------------------------------------------
            // SACAR NODO
            // ----------------------------------------------------

            var elemento =
                nodosPendientes.splice(
                    indiceMenor,
                    1
                )[0]

            var actual =
                elemento.nodo


            // ----------------------------------------------------
            // IGNORAR SI YA ESTÁ VISITADO
            // ----------------------------------------------------

            if (visitados[actual]) {
                continue
            }

            visitados[actual] = true


            // ----------------------------------------------------
            // HEMOS LLEGADO
            // ----------------------------------------------------

            if (actual === destino) {

                encontrado = true

                break
            }


            // ----------------------------------------------------
            // VECINOS
            // ----------------------------------------------------

            var vecinos =
                redCaminos[actual]

            if (!vecinos) {
                continue
            }


            // ----------------------------------------------------
            // RELAJAR CONEXIONES
            // ----------------------------------------------------

            for (
                var j = 0;
                j < vecinos.length;
                j++
            ) {

                var vecino =
                    vecinos[j].nodo

                if (visitados[vecino]) {
                    continue
                }


                var nuevaDistancia =
                    distancias[actual] +
                    vecinos[j].distancia


                if (
                    distancias[vecino] === undefined ||
                    nuevaDistancia <
                    distancias[vecino]
                ) {

                    distancias[vecino] =
                        nuevaDistancia

                    anterior[vecino] =
                        actual

                    lineaAnterior[vecino] =
                        vecinos[j].fid


                    nodosPendientes.push({
                        nodo: vecino,
                        distancia:
                            nuevaDistancia
                    })
                }
            }
        }


        // --------------------------------------------------------
        // NO EXISTE RUTA
        // --------------------------------------------------------

        if (!encontrado) {

            iface.mainWindow().displayToast(
                "No existe un recorrido entre los nodos"
            )

            return
        }


        // --------------------------------------------------------
        // RECONSTRUIR RUTA
        // --------------------------------------------------------

        var lineasRuta = []

        var actualRuta =
            destino


        while (
            actualRuta !== inicio
        ) {

            lineasRuta.unshift(
                lineaAnterior[actualRuta]
            )

            actualRuta =
                anterior[actualRuta]
        }


        // --------------------------------------------------------
        // DISTANCIA TOTAL
        // --------------------------------------------------------

        var distanciaTotal =
            distancias[destino]


        iface.mainWindow().displayToast(
            "Ruta encontrada: " +
            lineasRuta.length +
            " tramos"
        )


        // --------------------------------------------------------
        // VISUALIZAR
        // --------------------------------------------------------

        visualizarRuta(
            lineasRuta
        )
    }


    // ============================================================
    // VISUALIZAR RUTA
    // ============================================================

    function visualizarRuta(lineasRuta) {

        if (!caminoLineasLayer) {

            iface.mainWindow().displayToast(
                "No se encontró " +
                nombreCapaLineas
            )

            return
        }


        var indiceVisualizar =
            caminoLineasLayer.fields.indexOf(
                campoVisualizar
            )

        if (indiceVisualizar < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoVisualizar
            )

            return
        }


        // --------------------------------------------------------
        // FIDS DE LA RUTA
        // --------------------------------------------------------

        var rutaFids = {}

        for (
            var i = 0;
            i < lineasRuta.length;
            i++
        ) {

            rutaFids[
                String(lineasRuta[i])
            ] = true
        }


        // --------------------------------------------------------
        // EDITAR CAPA
        // --------------------------------------------------------

        if (
            !caminoLineasLayer.startEditing()
        ) {

            iface.mainWindow().displayToast(
                "No se pudo poner " +
                nombreCapaLineas +
                " en edición"
            )

            return
        }


        var it =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        var activadas = 0


        // --------------------------------------------------------
        // ACTUALIZAR VISUALIZAR
        // --------------------------------------------------------

        while (it.hasNext()) {

            var linea = it.next()

            var fid =
                String(
                    linea.attribute(
                        campoLineaFid
                    )
                )

            var activar =
                rutaFids[fid] === true

            var resultado =
                caminoLineasLayer.changeAttributeValue(
                    linea.id,
                    indiceVisualizar,
                    activar
                )

            if (
                resultado &&
                activar
            ) {

                activadas++
            }
        }


        // --------------------------------------------------------
        // GUARDAR
        // --------------------------------------------------------

        var guardado =
            caminoLineasLayer.commitChanges()

        if (!guardado) {

            iface.mainWindow().displayToast(
                "Error guardando " +
                campoVisualizar
            )

            return
        }


        caminoLineasLayer.triggerRepaint()

        rutaActiva = true


        iface.mainWindow().displayToast(
            "Ruta visualizada: " +
            activadas +
            " líneas"
        )
    }


    // ============================================================
    // DESMARCAR TODOS LOS CONTADORES
    // ============================================================

    function desmarcarTodosLosContadores() {

        if (!contadoresLayer) {

            contadoresLayer =
                qgisProject.mapLayersByName(
                    nombreCapaContadores
                )[0]
        }

        if (!contadoresLayer) {

            iface.mainWindow().displayToast(
                "No se encontró " +
                nombreCapaContadores
            )

            return false
        }


        var indiceSeleccionado =
            contadoresLayer.fields.indexOf(
                campoSeleccionado
            )

        if (indiceSeleccionado < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoSeleccionado
            )

            return false
        }


        if (
            !contadoresLayer.startEditing()
        ) {

            iface.mainWindow().displayToast(
                "No se pudo editar " +
                nombreCapaContadores
            )

            return false
        }


        var it =
            LayerUtils.createFeatureIterator(
                contadoresLayer
            )


        while (it.hasNext()) {

            var contador = it.next()

            contadoresLayer.changeAttributeValue(
                contador.id,
                indiceSeleccionado,
                false
            )
        }


        var guardado =
            contadoresLayer.commitChanges()

        if (!guardado) {

            iface.mainWindow().displayToast(
                "Error cancelando " +
                campoSeleccionado
            )

            return false
        }


        contadoresLayer.triggerRepaint()

        return true
    }


    // ============================================================
    // CANCELAR RUTA
    // ============================================================

    function cancelarRuta() {

        if (!caminoLineasLayer) {

            caminoLineasLayer =
                qgisProject.mapLayersByName(
                    nombreCapaLineas
                )[0]
        }

        if (!caminoLineasLayer) {

            iface.mainWindow().displayToast(
                "No se encontró " +
                nombreCapaLineas
            )

            return
        }


        var indiceVisualizar =
            caminoLineasLayer.fields.indexOf(
                campoVisualizar
            )

        if (indiceVisualizar < 0) {

            iface.mainWindow().displayToast(
                "No existe el campo " +
                campoVisualizar
            )

            return
        }


        if (
            !caminoLineasLayer.startEditing()
        ) {

            iface.mainWindow().displayToast(
                "No se pudo editar " +
                nombreCapaLineas
            )

            return
        }


        var it =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer
            )

        var desactivadas = 0


        while (it.hasNext()) {

            var linea = it.next()

            var resultado =
                caminoLineasLayer.changeAttributeValue(
                    linea.id,
                    indiceVisualizar,
                    false
                )

            if (resultado) {
                desactivadas++
            }
        }


        var guardado =
            caminoLineasLayer.commitChanges()

        if (!guardado) {

            iface.mainWindow().displayToast(
                "Error cancelando la ruta"
            )

            return
        }


        caminoLineasLayer.triggerRepaint()


        // --------------------------------------------------------
        // DESMARCAR CONTADOR
        // --------------------------------------------------------

        if (
            !desmarcarTodosLosContadores()
        ) {

            return
        }


        rutaActiva = false


        iface.mainWindow().displayToast(
            "Ruta cancelada"
        )
    }


    // ============================================================
    // BOTÓN PRINCIPAL
    // ============================================================

    QfToolButton {
        id: botonRuta

        iconSource:
            Qt.resolvedUrl("icon.png")

        bgcolor:
            Theme.toolButtonBackgroundColor

        round: true

        onClicked: {

            cargarContadores()

            actualizarLista()

            selectorContador.open()
        }
    }


    // ============================================================
    // BOTÓN X - CANCELAR
    // ============================================================

    QfToolButton {
        id: botonCancelar

        visible:
            rutaActiva

        iconSource:
            Theme.getThemeVectorIcon(
                "ic_close_white_24dp"
            )

        iconColor:
            Theme.toolButtonColor

        bgcolor:
            Theme.toolButtonBackgroundColor

        round: true

        onClicked: {

            cancelarRuta()
        }
    }


    // ============================================================
    // SELECTOR DE CONTADOR
    // ============================================================

    QfDialog {

        id: selectorContador

        parent:
            iface.mainWindow().contentItem

        width:
            Math.min(
                500,
                iface.mainWindow().width - 40
            )

        height:
            Math.min(
                700,
                iface.mainWindow().height - 40
            )

        x:
            (iface.mainWindow().width - width) / 2

        y:
            (iface.mainWindow().height - height) / 2

        title:
            "Seleccionar contador"

        Column {

            anchors.fill: parent

            anchors.margins: 16

            spacing: 10


            TextField {

                id: buscador

                width:
                    parent.width

                placeholderText:
                    "Buscar contador..."

                onTextChanged: {
                    actualizarLista()
                }
            }


            ListView {

                id: lista

                width:
                    parent.width

                height:
                    parent.height -
                    buscador.height -
                    10

                clip: true

                model:
                    listaModelo

                delegate:
                    ItemDelegate {

                    width:
                        lista.width

                    text:
                        model.nombre

                    onClicked: {

                        seleccionarContador(
                            model.id
                        )
                    }
                }
            }
        }
    }


    // ============================================================
    // MODELO
    // ============================================================

    ListModel {
        id: listaModelo
    }


    // ============================================================
    // INICIO
    // ============================================================

    Component.onCompleted: {

        iface.addItemToPluginsToolbar(
            botonRuta
        )

        iface.addItemToPluginsToolbar(
            botonCancelar
        )

        iface.mainWindow().displayToast(
            "Plugin de rutas cargado"
        )
    }
}
```
