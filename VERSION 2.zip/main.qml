import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
id: plugin

// ============================================================
// CONFIGURACION
// ============================================================

property string nombreCapaContadores: "CONTADORES LOS PINOS"
property string nombreCapaNodos: "CAMINO NODOS"
property string nombreCapaLineas: "CAMINO LINEAS"

property string campoContador: "Nº CONTADOR"
property string campoSeleccionado: "SELECCIONADO"

property string campoNodoFid: "fid"

property string campoLineaFid: "fid"
property string campoNodo1: "nodo1"
property string campoNodo2: "nodo2"
property string campoLongitud: "LONGITUD"
property string campoVisualizar: "VISUALIZAR"

// ============================================================
// CAPAS
// ============================================================

property var contadoresLayer: null
property var caminoNodosLayer: null
property var caminoLineasLayer: null

// ============================================================
// CONTADORES
// ============================================================

property var listaContadores: []

// ============================================================
// DESTINO
// ============================================================

property var destinoId: null
property string destinoNombre: ""
property var destinoGeometria: null
property var destinoPunto: null

// ============================================================
// NODOS
// ============================================================

property var nodoUsuarioFid: null
property var nodoDestinoFid: null

// ============================================================
// ESTADO DE RUTA
// ============================================================

property bool rutaActiva: false


// ============================================================
// CARGAR CONTADORES
// ============================================================

function cargarContadores() {

    contadoresLayer =
            qgisProject.mapLayersByName(
                nombreCapaContadores)[0]

    if (!contadoresLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de contadores")

        return
    }

    listaContadores = []

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    while (iterator.hasNext()) {

        let feature = iterator.next()

        listaContadores.push({
            id: feature.id,
            nombre: feature.attribute(
                campoContador)
        })
    }

    actualizarLista()
}


// ============================================================
// ACTUALIZAR LISTA
// ============================================================

function actualizarLista() {

    listaModelo.clear()

    let texto =
            buscador.text.toLowerCase()

    for (let i = 0;
         i < listaContadores.length;
         i++) {

        let nombre =
                String(listaContadores[i].nombre)

        if (texto === "" ||
                nombre.toLowerCase().indexOf(texto) !== -1) {

            listaModelo.append({
                featureId: listaContadores[i].id,
                nombre: nombre
            })
        }
    }
}


// ============================================================
// MARCAR CONTADOR SELECCIONADO
// ============================================================

function marcarContadorSeleccionado(featureId) {

    if (!contadoresLayer)
        return

    let indiceSeleccionado =
            contadoresLayer.fields.indexOf(
                campoSeleccionado)

    if (indiceSeleccionado < 0) {

        iface.mainWindow().displayToast(
            "No se encontró el campo " +
            campoSeleccionado)

        return
    }

    contadoresLayer.startEditing()

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    while (iterator.hasNext()) {

        let contador =
                iterator.next()

        let seleccionado =
                contador.id === featureId

        contadoresLayer.changeAttributeValue(
            contador.id,
            indiceSeleccionado,
            seleccionado)
    }

    contadoresLayer.commitChanges()
    contadoresLayer.triggerRepaint()
}


// ============================================================
// SELECCIONAR CONTADOR
// ============================================================

function seleccionarContador(featureId) {

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    let encontrado = false

    while (iterator.hasNext()) {

        let feature =
                iterator.next()

        if (feature.id === featureId) {

            encontrado = true

            destinoId =
                    feature.id

            destinoNombre =
                    String(feature.attribute(
                        campoContador))

            destinoGeometria =
                    feature.geometry

            destinoPunto =
                    feature.geometry.centroid()

            break
        }
    }

    if (!encontrado) {

        iface.mainWindow().displayToast(
            "No se encontró el contador")

        return
    }


    marcarContadorSeleccionado(
        featureId)


    let puntoProyecto =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs)

    iface.mapCanvas().mapSettings.center =
            puntoProyecto

    dialogoContadores.close()

    iface.mainWindow().displayToast(
        "Contador seleccionado: " +
        destinoNombre)

    buscarNodosMasCercanos()
}


// ============================================================
// BUSCAR NODO MAS CERCANO AL USUARIO
// Y NODO MAS CERCANO AL DESTINO
// ============================================================

function buscarNodosMasCercanos() {

    caminoNodosLayer =
            qgisProject.mapLayersByName(
                nombreCapaNodos)[0]

    if (!caminoNodosLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de nodos")

        return
    }

    let positioning =
            iface.findItemByObjectName(
                "positionSource")

    if (!positioning) {

        iface.mainWindow().displayToast(
            "No se encontró el GPS")

        return
    }

    if (!positioning.active) {

        iface.mainWindow().displayToast(
            "El GPS no está activo")

        return
    }

    let info =
            positioning.positionInformation

    if (!info.longitudeValid ||
            !info.latitudeValid) {

        iface.mainWindow().displayToast(
            "Posición GPS no válida")

        return
    }


    // --------------------------------------------------------
    // POSICION DEL USUARIO
    // --------------------------------------------------------

    let puntoUsuarioWgs84 =
            GeometryUtils.point(
                info.longitude,
                info.latitude)

    let puntoUsuario =
            GeometryUtils.reprojectPoint(
                puntoUsuarioWgs84,
                CoordinateReferenceSystemUtils.wgs84Crs(),
                qgisProject.crs)


    // --------------------------------------------------------
    // POSICION DEL DESTINO
    // --------------------------------------------------------

    let puntoDestino =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs)


    // --------------------------------------------------------
    // BUSCAR NODOS MAS CERCANOS
    // --------------------------------------------------------

    let distanciaUsuario =
            Number.POSITIVE_INFINITY

    let distanciaDestino =
            Number.POSITIVE_INFINITY

    let nodoUsuario = null
    let nodoDestino = null

    let iterator =
            LayerUtils.createFeatureIterator(
                caminoNodosLayer)

    while (iterator.hasNext()) {

        let nodo =
                iterator.next()

        let fidNodo =
                Number(nodo.attribute(
                    campoNodoFid))

        if (!isFinite(fidNodo))
            continue

        let puntoNodo =
                nodo.geometry.centroid()

        let puntoNodoProyecto =
                GeometryUtils.reprojectPoint(
                    puntoNodo,
                    caminoNodosLayer.crs,
                    qgisProject.crs)

        let dUsuario =
                GeometryUtils.distanceBetweenPoints(
                    puntoNodoProyecto,
                    puntoUsuario)

        let dDestino =
                GeometryUtils.distanceBetweenPoints(
                    puntoNodoProyecto,
                    puntoDestino)

        if (dUsuario < distanciaUsuario) {

            distanciaUsuario =
                    dUsuario

            nodoUsuario =
                    fidNodo
        }

        if (dDestino < distanciaDestino) {

            distanciaDestino =
                    dDestino

            nodoDestino =
                    fidNodo
        }
    }

    if (nodoUsuario === null) {

        iface.mainWindow().displayToast(
            "No se encontró el nodo del usuario")

        return
    }

    if (nodoDestino === null) {

        iface.mainWindow().displayToast(
            "No se encontró el nodo del destino")

        return
    }

    nodoUsuarioFid =
            nodoUsuario

    nodoDestinoFid =
            nodoDestino

    buscarRuta(
        nodoUsuarioFid,
        nodoDestinoFid)
}


// ============================================================
// BUSCAR RUTA - DIJKSTRA
//
// MISMA RED QUE EL CODIGO ORIGINAL:
//
// nodo1 <-> nodo2
//
// La unica diferencia respecto al BFS original es que ahora
// cada conexion tiene como peso el campo LONGITUD.
// ============================================================

function buscarRuta(inicio, destino) {

    caminoLineasLayer =
            qgisProject.mapLayersByName(
                nombreCapaLineas)[0]

    if (!caminoLineasLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de líneas")

        return
    }


    // --------------------------------------------------------
    // Indices de campos
    // --------------------------------------------------------

    let indiceNodo1 =
            caminoLineasLayer.fields.indexOf(
                campoNodo1)

    let indiceNodo2 =
            caminoLineasLayer.fields.indexOf(
                campoNodo2)

    let indiceLongitud =
            caminoLineasLayer.fields.indexOf(
                campoLongitud)

    let indiceLineaFid =
            caminoLineasLayer.fields.indexOf(
                campoLineaFid)

    if (indiceNodo1 < 0 ||
            indiceNodo2 < 0 ||
            indiceLongitud < 0 ||
            indiceLineaFid < 0) {

        iface.mainWindow().displayToast(
            "No se encontraron los campos de CAMINO LINEAS")

        return
    }


    // --------------------------------------------------------
    // CONSTRUIR RED
    //
    // Exactamente como en el BFS original, pero guardando
    // tambien LONGITUD.
    // --------------------------------------------------------

    let conexiones = {}

    let iterator =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer)

    while (iterator.hasNext()) {

        let linea =
                iterator.next()

        let nodo1 =
                Number(linea.attribute(
                    campoNodo1))

        let nodo2 =
                Number(linea.attribute(
                    campoNodo2))

        let distancia =
                Number(linea.attribute(
                    campoLongitud))

        let fidLinea =
                linea.attribute(
                    campoLineaFid)


        // ----------------------------------------------------
        // Ignorar datos invalidos
        // ----------------------------------------------------

        if (!isFinite(nodo1) ||
                !isFinite(nodo2) ||
                !isFinite(distancia)) {

            continue
        }


        // ----------------------------------------------------
        // Crear arrays de conexiones
        // ----------------------------------------------------

        if (!conexiones[nodo1])
            conexiones[nodo1] = []

        if (!conexiones[nodo2])
            conexiones[nodo2] = []


        // ----------------------------------------------------
        // SENTIDO nodo1 -> nodo2
        // ----------------------------------------------------

        conexiones[nodo1].push({
            nodo: nodo2,
            fid: fidLinea,
            distancia: distancia
        })


        // ----------------------------------------------------
        // SENTIDO nodo2 -> nodo1
        // ----------------------------------------------------

        conexiones[nodo2].push({
            nodo: nodo1,
            fid: fidLinea,
            distancia: distancia
        })
    }


    // ========================================================
    // DIJKSTRA
    // ========================================================

    let distancias = {}
    let anteriores = {}
    let lineasAnteriores = {}
    let visitados = {}

    let pendientes = []


    // --------------------------------------------------------
    // Nodo inicial
    // --------------------------------------------------------

    distancias[inicio] = 0

    pendientes.push({
        nodo: inicio,
        distancia: 0
    })


    // --------------------------------------------------------
    // Buscar mientras existan nodos pendientes
    // --------------------------------------------------------

    while (pendientes.length > 0) {

        // ----------------------------------------------------
        // Buscar el nodo pendiente con menor distancia
        // ----------------------------------------------------

        let indiceMinimo = 0

        for (let i = 1;
             i < pendientes.length;
             i++) {

            if (pendientes[i].distancia <
                    pendientes[indiceMinimo].distancia) {

                indiceMinimo = i
            }
        }


        // ----------------------------------------------------
        // Sacar nodo minimo
        // ----------------------------------------------------

        let actual =
                pendientes[indiceMinimo]

        pendientes.splice(
            indiceMinimo,
            1)

        let nodoActual =
                actual.nodo


        // ----------------------------------------------------
        // Si ya estaba visitado, continuar
        // ----------------------------------------------------

        if (visitados[nodoActual])
            continue


        visitados[nodoActual] = true


        // ----------------------------------------------------
        // Si hemos llegado al destino, terminar
        // ----------------------------------------------------

        if (nodoActual === destino)
            break


        // ----------------------------------------------------
        // Obtener conexiones
        // ----------------------------------------------------

        let vecinos =
                conexiones[nodoActual]

        if (!vecinos)
            continue


        // ----------------------------------------------------
        // Revisar conexiones
        // ----------------------------------------------------

        for (let i = 0;
             i < vecinos.length;
             i++) {

            let conexion =
                    vecinos[i]

            let vecino =
                    conexion.nodo


            if (visitados[vecino])
                continue


            // ------------------------------------------------
            // Nueva distancia acumulada
            // ------------------------------------------------

            let nuevaDistancia =
                    distancias[nodoActual] +
                    conexion.distancia


            // ------------------------------------------------
            // Si no conocemos el nodo o encontramos un camino
            // mas corto, actualizarlo.
            // ------------------------------------------------

            if (distancias[vecino] === undefined ||
                    nuevaDistancia < distancias[vecino]) {

                distancias[vecino] =
                        nuevaDistancia

                anteriores[vecino] =
                        nodoActual

                lineasAnteriores[vecino] =
                        conexion.fid

                pendientes.push({
                    nodo: vecino,
                    distancia: nuevaDistancia
                })
            }
        }
    }


    // ========================================================
    // COMPROBAR SI EXISTE RUTA
    // ========================================================

    if (distancias[destino] === undefined) {

        iface.mainWindow().displayToast(
            "No existe una ruta hasta el destino")

        return
    }


    // ========================================================
    // RECONSTRUIR RUTA
    //
    // Igual que en el BFS original: recuperamos los FID de
    // las lineas desde destino hasta inicio.
    // ========================================================

    let lineasRuta = []

    let nodoActual =
            destino

    while (nodoActual !== inicio) {

        if (lineasAnteriores[nodoActual] === undefined) {

            iface.mainWindow().displayToast(
                "No se pudo reconstruir la ruta")

            return
        }


        lineasRuta.unshift(
            lineasAnteriores[nodoActual])


        nodoActual =
                anteriores[nodoActual]
    }


    // ========================================================
    // VISUALIZAR RUTA
    // ========================================================

    visualizarRuta(
        lineasRuta)
}


// ============================================================
// VISUALIZAR RUTA
// ============================================================

function visualizarRuta(lineasRuta) {

    if (!caminoLineasLayer) {

        caminoLineasLayer =
                qgisProject.mapLayersByName(
                    nombreCapaLineas)[0]
    }

    if (!caminoLineasLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de líneas")

        return
    }

    let indiceVisualizar =
            caminoLineasLayer.fields.indexOf(
                campoVisualizar)

    if (indiceVisualizar < 0) {

        iface.mainWindow().displayToast(
            "No se encontró el campo " +
            campoVisualizar)

        return
    }


    // --------------------------------------------------------
    // Crear conjunto de FID de la ruta
    // --------------------------------------------------------

    let rutaFids = {}

    for (let i = 0;
         i < lineasRuta.length;
         i++) {

        rutaFids[
            String(lineasRuta[i])
        ] = true
    }


    // --------------------------------------------------------
    // Actualizar todas las líneas
    //
    // Las que pertenecian a una ruta anterior quedan en false.
    // --------------------------------------------------------

    caminoLineasLayer.startEditing()

    let iterator =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer)

    while (iterator.hasNext()) {

        let linea =
                iterator.next()

        let fid =
                String(linea.attribute(
                    campoLineaFid))

        let visualizar =
                rutaFids[fid] === true

        caminoLineasLayer.changeAttributeValue(
            linea.id,
            indiceVisualizar,
            visualizar)
    }

    caminoLineasLayer.commitChanges()
    caminoLineasLayer.triggerRepaint()

    rutaActiva = true

    iface.mainWindow().displayToast(
        "Ruta visualizada: " +
        lineasRuta.length +
        " líneas")
}


// ============================================================
// DESMARCAR TODOS LOS CONTADORES
// ============================================================

function desmarcarTodosLosContadores() {

    if (!contadoresLayer)
        return

    let indiceSeleccionado =
            contadoresLayer.fields.indexOf(
                campoSeleccionado)

    if (indiceSeleccionado < 0)
        return

    contadoresLayer.startEditing()

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    while (iterator.hasNext()) {

        let contador =
                iterator.next()

        contadoresLayer.changeAttributeValue(
            contador.id,
            indiceSeleccionado,
            false)
    }

    contadoresLayer.commitChanges()
    contadoresLayer.triggerRepaint()
}


// ============================================================
// CANCELAR RUTA
// ============================================================

function cancelarRuta() {

    caminoLineasLayer =
            qgisProject.mapLayersByName(
                nombreCapaLineas)[0]

    if (caminoLineasLayer) {

        let indiceVisualizar =
                caminoLineasLayer.fields.indexOf(
                    campoVisualizar)

        if (indiceVisualizar >= 0) {

            caminoLineasLayer.startEditing()

            let iterator =
                    LayerUtils.createFeatureIterator(
                        caminoLineasLayer)

            while (iterator.hasNext()) {

                let linea =
                        iterator.next()

                caminoLineasLayer.changeAttributeValue(
                    linea.id,
                    indiceVisualizar,
                    false)
            }

            caminoLineasLayer.commitChanges()
            caminoLineasLayer.triggerRepaint()
        }
    }

    desmarcarTodosLosContadores()

    rutaActiva = false

    iface.mainWindow().displayToast(
        "Ruta cancelada")
}


// ============================================================
// MODELO DE LISTA
// ============================================================

ListModel {
    id: listaModelo
}


// ============================================================
// BOTON DE RUTA
// ============================================================

QfToolButton {
    id: botonRuta

    iconSource: "icon.png"

    iconColor:
        Theme.toolButtonColor

    bgcolor:
        Theme.toolButtonBackgroundColor

    round: true

    onClicked: {

        cargarContadores()

        buscador.text = ""

        actualizarLista()

        dialogoContadores.open()
    }
}


// ============================================================
// BOTON CANCELAR
// ============================================================

QfToolButton {
    id: botonCancelar

    visible: rutaActiva

    iconSource:
        Theme.getThemeVectorIcon(
            "ic_close_white_24dp")

    iconColor:
        Theme.toolButtonColor

    bgcolor:
        Theme.toolButtonBackgroundColor

    round: true

    onClicked: {

        cancelarRuta()
    }
}


// ============================================================
// DIALOGO DE CONTADORES
// ============================================================

QfDialog {
    id: dialogoContadores

    parent:
        iface.mainWindow().contentItem

    title:
        "Seleccionar contador"

    width:
        Math.min(
            iface.mainWindow().width * 0.9,
            500)

    height:
        Math.min(
            iface.mainWindow().height * 0.8,
            600)

    modal: true

    Column {
        anchors.fill: parent

        spacing: 10

        TextField {
            id: buscador

            width:
                parent.width

            placeholderText:
                "Buscar contador..."

            onTextChanged: {

                actualizarLista()
            }
        }

        ListView {
            id: listaVista

            width:
                parent.width

            height:
                parent.height -
                buscador.height -
                10

            clip: true

            model:
                listaModelo

            delegate: ItemDelegate {

                width:
                    listaVista.width

                text:
                    model.nombre

                onClicked: {

                    seleccionarContador(
                        model.featureId)
                }
            }
        }
    }
}


// ============================================================
// INICIALIZACION
// ============================================================

Component.onCompleted: {

    iface.addItemToPluginsToolbar(
        botonRuta)

    iface.addItemToPluginsToolbar(
        botonCancelar)
}

}
