import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme

Item {
id: plugin

```
// ============================================================
// CONFIGURACION
// ============================================================

property string nombreCapaContadores: "CONTADORES LOS PINOS"
property string nombreCapaNodos: "CAMINO NODOS"
property string nombreCapaLineas: "CAMINO LINEAS"

property string campoContador: "Nº CONTADOR"
property string campoSeleccionado: "SELECCIONADO"

property string campoNodoFid: "fid"

property string campoLineaFid: "fid"
property string campoNodo1: "nodo1"
property string campoNodo2: "nodo2"
property string campoLongitud: "LONGITUD"
property string campoVisualizar: "VISUALIZAR"


// ============================================================
// CAPAS
// ============================================================

property var contadoresLayer: null
property var caminoNodosLayer: null
property var caminoLineasLayer: null


// ============================================================
// LISTA DE CONTADORES
// ============================================================

property var listaContadores: []


// ============================================================
// DESTINO
// ============================================================

property var destinoId: null
property string destinoNombre: ""
property var destinoGeometria: null
property var destinoPunto: null


// ============================================================
// NODOS
// ============================================================

property var nodoUsuarioFid: null
property var nodoDestinoFid: null


// ============================================================
// ESTADO DE RUTA
// ============================================================

property bool rutaActiva: false


// ============================================================
// RED DE CAMINOS
// ============================================================

property var redCaminos: ({})
property bool redCaminosCargada: false


// ============================================================
// CARGAR CONTADORES
// ============================================================

function cargarContadores() {

    contadoresLayer =
            qgisProject.mapLayersByName(
                nombreCapaContadores)[0]

    if (!contadoresLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de contadores")

        return
    }

    listaContadores = []

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    while (iterator.hasNext()) {

        let feature = iterator.next()

        listaContadores.push({
            id: feature.id,
            nombre: feature.attribute(
                campoContador)
        })
    }

    actualizarLista()
}


// ============================================================
// ACTUALIZAR LISTA
// ============================================================

function actualizarLista() {

    listaModelo.clear()

    let texto =
            buscador.text.toLowerCase()

    for (let i = 0;
         i < listaContadores.length;
         i++) {

        let nombre =
                String(listaContadores[i].nombre)

        if (texto === "" ||
                nombre.toLowerCase().indexOf(texto) !== -1) {

            listaModelo.append({
                featureId: listaContadores[i].id,
                nombre: nombre
            })
        }
    }
}


// ============================================================
// CARGAR RED DE CAMINOS
//
// La red se construye directamente desde CAMINO LINEAS.
//
// Cada línea:
//
// nodo1 -> nodo2
// nodo2 -> nodo1
//
// Peso:
//
// LONGITUD
// ============================================================

function cargarRedCaminos() {

    if (redCaminosCargada)
        return true

    caminoLineasLayer =
            qgisProject.mapLayersByName(
                nombreCapaLineas)[0]

    if (!caminoLineasLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de líneas")

        return false
    }

    let indiceNodo1 =
            caminoLineasLayer.fields.indexOf(
                campoNodo1)

    let indiceNodo2 =
            caminoLineasLayer.fields.indexOf(
                campoNodo2)

    let indiceLongitud =
            caminoLineasLayer.fields.indexOf(
                campoLongitud)

    let indiceFid =
            caminoLineasLayer.fields.indexOf(
                campoLineaFid)

    if (indiceNodo1 < 0 ||
            indiceNodo2 < 0 ||
            indiceLongitud < 0 ||
            indiceFid < 0) {

        iface.mainWindow().displayToast(
            "Faltan campos en CAMINO LINEAS")

        return false
    }

    let conexiones = {}

    let iterator =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer)

    while (iterator.hasNext()) {

        let linea = iterator.next()

        let nodo1 =
                Number(linea.attribute(
                    campoNodo1))

        let nodo2 =
                Number(linea.attribute(
                    campoNodo2))

        let distancia =
                Number(linea.attribute(
                    campoLongitud))

        let fidLinea =
                linea.attribute(
                    campoLineaFid)

        if (!isFinite(nodo1) ||
                !isFinite(nodo2) ||
                !isFinite(distancia)) {

            continue
        }

        if (distancia < 0)
            continue

        if (!conexiones[nodo1])
            conexiones[nodo1] = []

        if (!conexiones[nodo2])
            conexiones[nodo2] = []


        // ----------------------------------------------------
        // SENTIDO 1
        // ----------------------------------------------------

        conexiones[nodo1].push({
            nodo: nodo2,
            fid: fidLinea,
            distancia: distancia
        })


        // ----------------------------------------------------
        // SENTIDO 2
        // ----------------------------------------------------

        conexiones[nodo2].push({
            nodo: nodo1,
            fid: fidLinea,
            distancia: distancia
        })
    }

    redCaminos = conexiones
    redCaminosCargada = true

    return true
}


// ============================================================
// MARCAR CONTADOR SELECCIONADO
// ============================================================

function marcarContadorSeleccionado(featureId) {

    if (!contadoresLayer)
        return

    let indiceSeleccionado =
            contadoresLayer.fields.indexOf(
                campoSeleccionado)

    if (indiceSeleccionado < 0) {

        iface.mainWindow().displayToast(
            "No se encontró el campo " +
            campoSeleccionado)

        return
    }

    contadoresLayer.startEditing()

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    while (iterator.hasNext()) {

        let contador =
                iterator.next()

        let seleccionado =
                contador.id === featureId

        contadoresLayer.changeAttributeValue(
            contador.id,
            indiceSeleccionado,
            seleccionado)
    }

    contadoresLayer.commitChanges()
    contadoresLayer.triggerRepaint()
}


// ============================================================
// SELECCIONAR CONTADOR
// ============================================================

function seleccionarContador(featureId) {

    if (!cargarRedCaminos())
        return

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    let encontrado = false

    while (iterator.hasNext()) {

        let feature =
                iterator.next()

        if (feature.id === featureId) {

            encontrado = true

            destinoId =
                    feature.id

            destinoNombre =
                    String(feature.attribute(
                        campoContador))

            destinoGeometria =
                    feature.geometry

            destinoPunto =
                    feature.geometry.centroid()

            break
        }
    }

    if (!encontrado) {

        iface.mainWindow().displayToast(
            "No se encontró el contador")

        return
    }


    // --------------------------------------------------------
    // Marcar contador
    // --------------------------------------------------------

    marcarContadorSeleccionado(
        featureId)


    // --------------------------------------------------------
    // Centrar mapa en el contador
    // --------------------------------------------------------

    let puntoProyecto =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs)

    iface.mapCanvas().mapSettings.center =
            puntoProyecto


    // --------------------------------------------------------
    // Cerrar selector
    // --------------------------------------------------------

    dialogoContadores.close()


    iface.mainWindow().displayToast(
        "Contador seleccionado: " +
        destinoNombre)


    // --------------------------------------------------------
    // Buscar nodos y calcular ruta
    // --------------------------------------------------------

    buscarNodosMasCercanos()
}


// ============================================================
// BUSCAR NODO MAS CERCANO AL USUARIO
// Y NODO MAS CERCANO AL DESTINO
// ============================================================

function buscarNodosMasCercanos() {

    caminoNodosLayer =
            qgisProject.mapLayersByName(
                nombreCapaNodos)[0]

    if (!caminoNodosLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de nodos")

        return
    }


    // --------------------------------------------------------
    // POSICIONAMIENTO QFIELD
    // --------------------------------------------------------

    let positioning =
            iface.findItemByObjectName(
                "positionSource")

    if (!positioning) {

        iface.mainWindow().displayToast(
            "No se encontró el GPS")

        return
    }

    if (!positioning.active) {

        iface.mainWindow().displayToast(
            "El GPS no está activo")

        return
    }

    let info =
            positioning.positionInformation

    if (!info.longitudeValid ||
            !info.latitudeValid) {

        iface.mainWindow().displayToast(
            "Posición GPS no válida")

        return
    }


    // --------------------------------------------------------
    // PUNTO DEL USUARIO
    // --------------------------------------------------------

    let puntoUsuarioWgs84 =
            GeometryUtils.point(
                info.longitude,
                info.latitude)

    let puntoUsuario =
            GeometryUtils.reprojectPoint(
                puntoUsuarioWgs84,
                CoordinateReferenceSystemUtils.wgs84Crs(),
                qgisProject.crs)


    // --------------------------------------------------------
    // PUNTO DEL DESTINO
    // --------------------------------------------------------

    let puntoDestino =
            GeometryUtils.reprojectPoint(
                destinoPunto,
                contadoresLayer.crs,
                qgisProject.crs)


    // --------------------------------------------------------
    // VARIABLES DE BUSQUEDA
    // --------------------------------------------------------

    let distanciaUsuario =
            Number.POSITIVE_INFINITY

    let distanciaDestino =
            Number.POSITIVE_INFINITY

    let nodoUsuario = null
    let nodoDestino = null


    // --------------------------------------------------------
    // RECORRER NODOS
    // --------------------------------------------------------

    let iterator =
            LayerUtils.createFeatureIterator(
                caminoNodosLayer)

    while (iterator.hasNext()) {

        let nodo =
                iterator.next()

        let fidNodo =
                Number(nodo.attribute(
                    campoNodoFid))

        if (!isFinite(fidNodo))
            continue

        let puntoNodo =
                nodo.geometry.centroid()

        let puntoNodoProyecto =
                GeometryUtils.reprojectPoint(
                    puntoNodo,
                    caminoNodosLayer.crs,
                    qgisProject.crs)


        // ----------------------------------------------------
        // DISTANCIA AL USUARIO
        // ----------------------------------------------------

        let dUsuario =
                GeometryUtils.distanceBetweenPoints(
                    puntoNodoProyecto,
                    puntoUsuario)


        // ----------------------------------------------------
        // DISTANCIA AL DESTINO
        // ----------------------------------------------------

        let dDestino =
                GeometryUtils.distanceBetweenPoints(
                    puntoNodoProyecto,
                    puntoDestino)


        if (dUsuario < distanciaUsuario) {

            distanciaUsuario =
                    dUsuario

            nodoUsuario =
                    fidNodo
        }


        if (dDestino < distanciaDestino) {

            distanciaDestino =
                    dDestino

            nodoDestino =
                    fidNodo
        }
    }


    // --------------------------------------------------------
    // COMPROBACIONES
    // --------------------------------------------------------

    if (nodoUsuario === null) {

        iface.mainWindow().displayToast(
            "No se encontró el nodo del usuario")

        return
    }

    if (nodoDestino === null) {

        iface.mainWindow().displayToast(
            "No se encontró el nodo del destino")

        return
    }


    nodoUsuarioFid =
            nodoUsuario

    nodoDestinoFid =
            nodoDestino


    // --------------------------------------------------------
    // CALCULAR RUTA
    // --------------------------------------------------------

    buscarRuta(
        nodoUsuarioFid,
        nodoDestinoFid)
}


// ============================================================
// DIJKSTRA
//
// Calcula el camino de menor suma de LONGITUD.
//
// No utiliza ninguna API externa.
// Trabaja exclusivamente con la red cargada desde
// CAMINO LINEAS.
// ============================================================

function buscarRuta(inicio, destino) {

    if (!redCaminosCargada) {

        if (!cargarRedCaminos())
            return
    }


    // --------------------------------------------------------
    // Estructuras de Dijkstra
    // --------------------------------------------------------

    let distancias = {}
    let anterior = {}
    let lineaAnterior = {}
    let visitados = {}
    let pendientes = []


    // --------------------------------------------------------
    // Distancia inicial
    // --------------------------------------------------------

    distancias[inicio] = 0

    pendientes.push({
        nodo: inicio,
        distancia: 0
    })


    // ========================================================
    // ALGORITMO
    // ========================================================

    while (pendientes.length > 0) {


        // ----------------------------------------------------
        // Buscar el pendiente con menor distancia
        // ----------------------------------------------------

        let posicionMinima = 0

        for (let i = 1;
             i < pendientes.length;
             i++) {

            if (pendientes[i].distancia <
                    pendientes[posicionMinima].distancia) {

                posicionMinima = i
            }
        }


        let actual =
                pendientes[posicionMinima]

        pendientes.splice(
            posicionMinima,
            1)


        let nodoActual =
                actual.nodo


        // ----------------------------------------------------
        // Ignorar si ya fue procesado
        // ----------------------------------------------------

        if (visitados[nodoActual])
            continue


        visitados[nodoActual] = true


        // ----------------------------------------------------
        // Llegamos al destino
        // ----------------------------------------------------

        if (nodoActual === destino)
            break


        // ----------------------------------------------------
        // Obtener vecinos
        // ----------------------------------------------------

        let vecinos =
                redCaminos[nodoActual]

        if (!vecinos)
            continue


        // ----------------------------------------------------
        // RELAJAR VECINOS
        // ----------------------------------------------------

        for (let i = 0;
             i < vecinos.length;
             i++) {

            let conexion =
                    vecinos[i]

            let vecino =
                    conexion.nodo


            if (visitados[vecino])
                continue


            let nuevaDistancia =
                    distancias[nodoActual] +
                    conexion.distancia


            // ------------------------------------------------
            // Si encontramos un camino mejor
            // ------------------------------------------------

            if (distancias[vecino] === undefined ||
                    nuevaDistancia < distancias[vecino]) {

                distancias[vecino] =
                        nuevaDistancia

                anterior[vecino] =
                        nodoActual

                lineaAnterior[vecino] =
                        conexion.fid


                pendientes.push({
                    nodo: vecino,
                    distancia: nuevaDistancia
                })
            }
        }
    }


    // ========================================================
    // NO EXISTE RUTA
    // ========================================================

    if (distancias[destino] === undefined) {

        iface.mainWindow().displayToast(
            "No existe una ruta hasta el destino")

        return
    }


    // ========================================================
    // RECONSTRUIR RUTA
    // ========================================================

    let lineasRuta = []

    let nodoActual =
            destino


    while (nodoActual !== inicio) {

        if (lineaAnterior[nodoActual] === undefined) {

            iface.mainWindow().displayToast(
                "No se pudo reconstruir la ruta")

            return
        }


        lineasRuta.unshift(
            lineaAnterior[nodoActual])


        nodoActual =
                anterior[nodoActual]
    }


    // ========================================================
    // MOSTRAR RUTA
    // ========================================================

    visualizarRuta(
        lineasRuta)
}


// ============================================================
// VISUALIZAR RUTA
//
// Todas las líneas pasan a false.
// Las líneas de la ruta pasan a true.
//
// Por tanto, seleccionar una nueva ruta sustituye
// automáticamente la anterior.
// ============================================================

function visualizarRuta(lineasRuta) {

    if (!caminoLineasLayer) {

        caminoLineasLayer =
                qgisProject.mapLayersByName(
                    nombreCapaLineas)[0]
    }

    if (!caminoLineasLayer) {

        iface.mainWindow().displayToast(
            "No se encontró la capa de líneas")

        return
    }


    let indiceVisualizar =
            caminoLineasLayer.fields.indexOf(
                campoVisualizar)

    if (indiceVisualizar < 0) {

        iface.mainWindow().displayToast(
            "No se encontró el campo " +
            campoVisualizar)

        return
    }


    // --------------------------------------------------------
    // Crear conjunto de FID
    // --------------------------------------------------------

    let rutaFids = {}

    for (let i = 0;
         i < lineasRuta.length;
         i++) {

        rutaFids[
            String(lineasRuta[i])
        ] = true
    }


    // --------------------------------------------------------
    // Actualizar TODAS las líneas
    // --------------------------------------------------------

    caminoLineasLayer.startEditing()

    let iterator =
            LayerUtils.createFeatureIterator(
                caminoLineasLayer)

    while (iterator.hasNext()) {

        let linea =
                iterator.next()

        let fid =
                String(linea.attribute(
                    campoLineaFid))

        let visualizar =
                rutaFids[fid] === true

        caminoLineasLayer.changeAttributeValue(
            linea.id,
            indiceVisualizar,
            visualizar)
    }


    caminoLineasLayer.commitChanges()
    caminoLineasLayer.triggerRepaint()


    rutaActiva = true


    iface.mainWindow().displayToast(
        "Ruta visualizada: " +
        lineasRuta.length +
        " líneas")
}


// ============================================================
// DESMARCAR TODOS LOS CONTADORES
// ============================================================

function desmarcarTodosLosContadores() {

    if (!contadoresLayer)
        return

    let indiceSeleccionado =
            contadoresLayer.fields.indexOf(
                campoSeleccionado)

    if (indiceSeleccionado < 0)
        return


    contadoresLayer.startEditing()

    let iterator =
            LayerUtils.createFeatureIterator(
                contadoresLayer)

    while (iterator.hasNext()) {

        let contador =
                iterator.next()

        contadoresLayer.changeAttributeValue(
            contador.id,
            indiceSeleccionado,
            false)
    }


    contadoresLayer.commitChanges()
    contadoresLayer.triggerRepaint()
}


// ============================================================
// CANCELAR RUTA
// ============================================================

function cancelarRuta() {

    caminoLineasLayer =
            qgisProject.mapLayersByName(
                nombreCapaLineas)[0]


    if (caminoLineasLayer) {

        let indiceVisualizar =
                caminoLineasLayer.fields.indexOf(
                    campoVisualizar)

        if (indiceVisualizar >= 0) {

            caminoLineasLayer.startEditing()

            let iterator =
                    LayerUtils.createFeatureIterator(
                        caminoLineasLayer)

            while (iterator.hasNext()) {

                let linea =
                        iterator.next()

                caminoLineasLayer.changeAttributeValue(
                    linea.id,
                    indiceVisualizar,
                    false)
            }


            caminoLineasLayer.commitChanges()
            caminoLineasLayer.triggerRepaint()
        }
    }


    // --------------------------------------------------------
    // Quitar selección de contadores
    // --------------------------------------------------------

    desmarcarTodosLosContadores()


    // --------------------------------------------------------
    // Estado
    // --------------------------------------------------------

    rutaActiva = false


    iface.mainWindow().displayToast(
        "Ruta cancelada")
}


// ============================================================
// MODELO DE LISTA
// ============================================================

ListModel {
    id: listaModelo
}


// ============================================================
// BOTON DE RUTA
// ============================================================

QfToolButton {
    id: botonRuta

    iconSource: "icon.png"

    iconColor:
        Theme.toolButtonColor

    bgcolor:
        Theme.toolButtonBackgroundColor

    round: true

    onClicked: {

        cargarContadores()

        buscador.text = ""

        actualizarLista()

        dialogoContadores.open()
    }
}


// ============================================================
// BOTON CANCELAR
// ============================================================

QfToolButton {
    id: botonCancelar

    visible: rutaActiva

    iconSource:
        Theme.getThemeVectorIcon(
            "ic_close_white_24dp")

    iconColor:
        Theme.toolButtonColor

    bgcolor:
        Theme.toolButtonBackgroundColor

    round: true

    onClicked: {

        cancelarRuta()
    }
}


// ============================================================
// DIALOGO
// ============================================================

QfDialog {
    id: dialogoContadores

    parent:
        iface.mainWindow().contentItem

    title:
        "Seleccionar contador"

    width:
        Math.min(
            iface.mainWindow().width * 0.9,
            500)

    height:
        Math.min(
            iface.mainWindow().height * 0.8,
            600)

    modal: true


    Column {
        anchors.fill: parent

        spacing: 10


        // ----------------------------------------------------
        // BUSCADOR
        // ----------------------------------------------------

        TextField {
            id: buscador

            width:
                parent.width

            placeholderText:
                "Buscar contador..."

            onTextChanged: {

                actualizarLista()
            }
        }


        // ----------------------------------------------------
        // LISTA
        // ----------------------------------------------------

        ListView {
            id: listaVista

            width:
                parent.width

            height:
                parent.height -
                buscador.height -
                10

            clip: true

            model:
                listaModelo


            delegate: ItemDelegate {

                width:
                    listaVista.width

                text:
                    model.nombre


                onClicked: {

                    seleccionarContador(
                        model.featureId)
                }
            }
        }
    }
}


// ============================================================
// INICIALIZACION DEL PLUGIN
// ============================================================

Component.onCompleted: {

    iface.addItemToPluginsToolbar(
        botonRuta)

    iface.addItemToPluginsToolbar(
        botonCancelar)
}
```

}
